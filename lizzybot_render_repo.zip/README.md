# LizzyBot

A fully automated AI Telegram bot integrated with Ko-fi and MongoDB.